import {NextResponse} from 'next/server';
import {createClient} from '@supabase/supabase-js';

function db(token:string){
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!,{auth:{persistSession:false},global:{headers:{Authorization:`Bearer ${token}`}}});
}

export async function GET(req:Request){
  const token=(req.headers.get('authorization')||'').replace(/^Bearer\s+/i,'');
  if(!token)return NextResponse.json({error:'Sign in required'},{status:401});
  const supabase=db(token);
  const {data:u}=await supabase.auth.getUser(token);
  if(!u.user)return NextResponse.json({error:'Invalid session'},{status:401});
  const {data:reservations,error:re}=await supabase.from('property_reservations').select('id,unit_id,status,payment_status,created_at,updated_at').eq('buyer_user_id',u.user.id).order('created_at',{ascending:false});
  if(re)return NextResponse.json({error:re.message},{status:500});
  const ids=(reservations||[]).map((r:any)=>r.id);
  if(!ids.length)return NextResponse.json({timeline:[]});
  const [{data:activities,error:ae},{data:events,error:ee}]=await Promise.all([
    supabase.from('property_activity_log').select('*').in('reservation_id',ids).order('created_at',{ascending:false}).limit(100),
    supabase.from('property_reservation_events').select('*').in('reservation_id',ids).order('created_at',{ascending:false}).limit(100)
  ]);
  if(ae)return NextResponse.json({error:ae.message},{status:500});
  if(ee)return NextResponse.json({error:ee.message},{status:500});
  const timeline=[...(activities||[]).map((a:any)=>({...a,source:'activity'})),...(events||[]).map((e:any)=>({...e,source:'reservation_event'}))].sort((a:any,b:any)=>new Date(b.created_at).getTime()-new Date(a.created_at).getTime()).slice(0,100);
  return NextResponse.json({timeline});
}
