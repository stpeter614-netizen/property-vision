import {NextResponse} from "next/server";
import Stripe from "stripe";
import {createClient} from "@supabase/supabase-js";

export async function POST(req:Request){
 const sig=req.headers.get("stripe-signature"), sk=process.env.STRIPE_SECRET_KEY, wh=process.env.STRIPE_WEBHOOK_SECRET;
 if(!sig||!sk||!wh)return NextResponse.json({error:"Stripe webhook not configured"},{status:400});
 const raw=await req.text(); let event:Stripe.Event;
 try{event=new Stripe(sk).webhooks.constructEvent(raw,sig,wh)}catch{return NextResponse.json({error:"Invalid signature"},{status:400})}
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(event.type==="checkout.session.completed"&&url&&key){
  const s=event.data.object as Stripe.Checkout.Session;
  const rid=s.metadata?.reservationId;
  if(rid){
   const db=createClient(url,key,{auth:{persistSession:false}});
   const {error}=await db.rpc("confirm_property_payment",{p_reservation_id:rid,p_stripe_session_id:s.id,p_amount_received:s.amount_total||0,p_stripe_event_id:event.id});
   if(error)return NextResponse.json({error:error.message},{status:500});
  }
 }
 return NextResponse.json({received:true});
}