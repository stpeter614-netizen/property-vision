import {NextResponse} from "next/server";
import {createClient} from "@supabase/supabase-js";

export async function PATCH(req:Request){
 const body=await req.json();
 const {unitId,status}=body||{};
 if(!unitId||!["available","reserved","sold","off_market"].includes(status))
  return NextResponse.json({error:"Invalid unit status"},{status:400});
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key) return NextResponse.json({mode:"demo",unitId,status});
 const db=createClient(url,key,{auth:{persistSession:false}});
 const {error}=await db.from("units").update({status}).eq("id",unitId);
 if(error)return NextResponse.json({error:error.message},{status:500});
 return NextResponse.json({unitId,status});
}