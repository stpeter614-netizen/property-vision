import {NextResponse} from "next/server";
import {createClient} from "@supabase/supabase-js";
export async function POST(req:Request){
 const {email,password}=await req.json();
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
 if(!url||!key)return NextResponse.json({mode:"demo",message:"Configure Supabase Auth to enable sign-in."});
 const db=createClient(url,key);
 const {data,error}=await db.auth.signInWithPassword({email,password});
 if(error)return NextResponse.json({error:error.message},{status:401});
 return NextResponse.json({user:data.user,session:data.session});
}