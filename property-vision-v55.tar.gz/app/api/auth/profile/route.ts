import {NextResponse} from "next/server";
import {createClient} from "@supabase/supabase-js";
export async function GET(req:Request){
 const auth=req.headers.get("authorization");
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL, anon=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
 if(!auth||!url||!anon)return NextResponse.json({authenticated:false});
 const db=createClient(url,anon,{global:{headers:{Authorization:auth}}});
 const {data,error}=await db.auth.getUser();
 if(error||!data.user)return NextResponse.json({authenticated:false});
 return NextResponse.json({authenticated:true,user:{id:data.user.id,email:data.user.email}});
}