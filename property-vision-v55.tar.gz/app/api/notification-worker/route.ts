import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { sendExternal } from './providers';

const CHANNELS = new Set(['email', 'sms', 'whatsapp', 'in_app']);
const MAX_ATTEMPTS = 5;

function db() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } },
  );
}

function authorized(req: Request) {
  const secret = process.env.NOTIFICATION_WORKER_SECRET;
  return !!secret && req.headers.get('x-notification-worker-secret') === secret;
}

function backoff(attempt: number) {
  return Math.min(60 * 60, Math.pow(2, Math.max(0, attempt - 1)) * 60);
}

async function claim(supabase: ReturnType<typeof db>, id: string) {
  const { data, error } = await supabase
    .from('property_notification_deliveries')
    .update({ status: 'processing', last_attempt_at: new Date().toISOString(), updated_at: new Date().toISOString() })
    .eq('id', id)
    .in('status', ['queued', 'failed'])
    .lte('next_attempt_at', new Date().toISOString())
    .select('*, property_notifications(title, message)')
    .maybeSingle();
  return { data, error };
}

async function runWorker(req: Request) {
  const cronSecret = process.env.CRON_SECRET;
  const cronAuthorized = !!cronSecret && req.headers.get('authorization') === `Bearer ${cronSecret}`;
  if (!authorized(req) && !cronAuthorized) return NextResponse.json({ error: 'Worker authorization required' }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const limit = Math.min(Math.max(Number(body.limit || 25), 1), 100);
  const supabase = db();

  const { data: due, error } = await supabase
    .from('property_notification_deliveries')
    .select('*')
    .in('status', ['queued', 'failed'])
    .lte('next_attempt_at', new Date().toISOString())
    .order('next_attempt_at', { ascending: true })
    .limit(limit);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const results: Array<Record<string, unknown>> = [];
  for (const candidate of due || []) {
    const { data: job, error: claimError } = await claim(supabase, candidate.id);
    if (claimError) {
      results.push({ id: candidate.id, status: 'claim_error', error: claimError.message });
      continue;
    }
    if (!job) {
      results.push({ id: candidate.id, status: 'skipped_claimed_elsewhere' });
      continue;
    }

    const attempt = Number(job.attempt_count || 0) + 1;
    const channel = String(job.channel);
    let nextStatus = 'sent';
    let lastError: string | null = null;

    if (!CHANNELS.has(channel)) {
      nextStatus = 'failed';
      lastError = `Unsupported notification channel: ${channel}`;
    } else if (channel === 'in_app') {
      // In-app delivery is represented by the notification row itself.
      nextStatus = 'sent';
    } else if (!job.destination) {
      nextStatus = 'failed';
      lastError = 'No destination configured for this delivery channel.';
    } else {
      const providerResult = await sendExternal({ ...job, channel, notification: Array.isArray(job.property_notifications) ? job.property_notifications[0] : job.property_notifications });
      if (providerResult.sent) {
        const { error: updateError } = await supabase.from('property_notification_deliveries').update({
          status: 'sent', attempt_count: attempt, sent_at: new Date().toISOString(), failed_at: null,
          last_attempt_at: new Date().toISOString(), last_error: null, provider: providerResult.provider || null,
          provider_message_id: providerResult.provider_message_id || null, updated_at: new Date().toISOString(),
        }).eq('id', job.id).eq('status', 'processing');
        results.push({ id: job.id, channel, status: updateError ? 'update_error' : 'sent', attempt, provider: providerResult.provider, provider_message_id: providerResult.provider_message_id, error: updateError?.message });
        continue;
      }
      nextStatus = 'failed';
      lastError = providerResult.error || `${channel} provider failed.`;
    }

    if (nextStatus === 'sent') {
      const { error: updateError } = await supabase
        .from('property_notification_deliveries')
        .update({
          status: 'sent',
          attempt_count: attempt,
          last_attempt_at: new Date().toISOString(),
          sent_at: new Date().toISOString(),
          failed_at: null,
          last_error: null,
          provider: channel === 'in_app' ? 'internal' : null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', job.id)
        .eq('status', 'processing');
      results.push({ id: job.id, channel, status: updateError ? 'update_error' : 'sent', attempt, error: updateError?.message });
      continue;
    }

    const exhausted = attempt >= MAX_ATTEMPTS;
    const nextAttempt = new Date(Date.now() + backoff(attempt) * 1000).toISOString();
    const { error: updateError } = await supabase
      .from('property_notification_deliveries')
      .update({
        status: exhausted ? 'cancelled' : 'failed',
        attempt_count: attempt,
        next_attempt_at: nextAttempt,
        last_attempt_at: new Date().toISOString(),
        failed_at: new Date().toISOString(),
        last_error: exhausted ? `${lastError} Maximum attempts reached.` : lastError,
        updated_at: new Date().toISOString(),
      })
      .eq('id', job.id)
      .eq('status', 'processing');

    results.push({ id: job.id, channel, status: updateError ? 'update_error' : (exhausted ? 'cancelled' : 'failed'), attempt, retry_at: exhausted ? null : nextAttempt, error: updateError?.message || lastError });
  }

  return NextResponse.json({ processed: results.length, results });
}

export async function POST(req: Request) { return runWorker(req); }

export async function GET(req: Request) { return runWorker(req); }
