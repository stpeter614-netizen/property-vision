export type DeliveryJob = {
  id: string; channel: string; destination: string | null; attempt_count?: number;
  notification?: { title?: string | null; message?: string | null } | null;
};

export type ProviderResult = { sent: boolean; provider?: string; provider_message_id?: string | null; error?: string };

function text(job: DeliveryJob) {
  return {
    title: job.notification?.title || 'Property Vision notification',
    message: job.notification?.message || '',
  };
}

export async function sendExternal(job: DeliveryJob): Promise<ProviderResult> {
  if (!job.destination) return { sent: false, error: 'No destination configured.' };
  const { title, message } = text(job);

  if (job.channel === 'email') {
    const key = process.env.RESEND_API_KEY;
    const from = process.env.RESEND_FROM_EMAIL;
    if (!key || !from) return { sent: false, error: 'Email provider not configured (RESEND_API_KEY/RESEND_FROM_EMAIL).' };
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to: [job.destination], subject: title, text: message }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { sent: false, provider: 'resend', error: data?.message || `Resend HTTP ${res.status}` };
    return { sent: true, provider: 'resend', provider_message_id: data?.id || null };
  }

  if (job.channel === 'sms' || job.channel === 'whatsapp') {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = job.channel === 'whatsapp' ? process.env.TWILIO_WHATSAPP_FROM : process.env.TWILIO_SMS_FROM;
    if (!sid || !token || !from) return { sent: false, error: `Twilio ${job.channel} provider not configured.` };
    const to = job.channel === 'whatsapp' ? `whatsapp:${job.destination}` : job.destination;
    const body = new URLSearchParams({ To: to, From: from, Body: message });
    const auth = Buffer.from(`${sid}:${token}`).toString('base64');
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { sent: false, provider: 'twilio', error: data?.message || `Twilio HTTP ${res.status}` };
    return { sent: true, provider: 'twilio', provider_message_id: data?.sid || null };
  }
  return { sent: false, error: `Unsupported notification channel: ${job.channel}` };
}
