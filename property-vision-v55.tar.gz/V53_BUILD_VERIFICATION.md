# Property Vision V53 — Build Verification

## Result

**SOURCE GATE: PASS** — the archive has been flattened into a normal Next.js repository and the required bootstrap files are present.

**DEPENDENCY GATE: BLOCKED IN THIS ENVIRONMENT** — Node.js 22 is available, but `node_modules` is absent and `npm install --no-audit --no-fund` timed out. No claim of a successful `next build` is made.

## Required production command

```bash
npm ci
npm run build
npm start
```

If there is no lockfile yet, run `npm install` once in the intended development/Vercel environment, commit the generated lockfile, then use `npm ci` in CI.

## Environment variables referenced by the source

- NEXT_PUBLIC_APP_URL
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY
- SUPABASE_SERVICE_ROLE_KEY
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- CRON_SECRET
- NOTIFICATION_WORKER_SECRET
- RESEND_API_KEY
- RESEND_FROM_EMAIL
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_SMS_FROM
- TWILIO_WHATSAPP_FROM

## Important

This package is **not** deployed to the existing WOX Vercel project. A separate Property Vision Vercel project must be selected/created before deployment.
