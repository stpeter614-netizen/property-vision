import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'package.json','next-env.d.ts','tsconfig.json','next.config.ts',
  'app/layout.tsx','app/page.tsx','app/globals.css','vercel.json'
];
const envNames = [
  'NEXT_PUBLIC_SUPABASE_URL','NEXT_PUBLIC_SUPABASE_ANON_KEY',
  'SUPABASE_SERVICE_ROLE_KEY','STRIPE_SECRET_KEY','STRIPE_WEBHOOK_SECRET',
  'NOTIFICATION_WORKER_SECRET','CRON_SECRET','RESEND_API_KEY','RESEND_FROM_EMAIL',
  'TWILIO_ACCOUNT_SID','TWILIO_AUTH_TOKEN','TWILIO_SMS_FROM','TWILIO_WHATSAPP_FROM'
];
let failed = false;
for (const f of required) {
  if (!fs.existsSync(path.join(root,f))) { console.error(`MISSING ${f}`); failed=true; }
}
const files=[];
function walk(dir){ for(const e of fs.readdirSync(dir,{withFileTypes:true})){ if(e.name==='node_modules'||e.name==='.next') continue; const p=path.join(dir,e.name); e.isDirectory()?walk(p):files.push(p); }}
walk(path.join(root,'app'));
const missing=[];
for(const file of files.filter(f=>/\.(ts|tsx)$/.test(f))){
  const src=fs.readFileSync(file,'utf8');
  for(const m of src.matchAll(/(?:from|import)\s*['"](\.\.?\/[^'"]+)['"]/g)){
    const spec=m[1], base=path.resolve(path.dirname(file),spec);
    const candidates=[base,`${base}.ts`,`${base}.tsx`,`${base}.js`,`${base}.jsx`,`${base}.css`,path.join(base,'index.ts'),path.join(base,'index.tsx')];
    if(!candidates.some(fs.existsSync)) missing.push(`${path.relative(root,file)} -> ${spec}`);
  }
}
if(missing.length){ console.error('MISSING LOCAL IMPORTS'); missing.forEach(x=>console.error(x)); failed=true; }
console.log(`Source files checked: ${files.length}`);
console.log(`Environment variables required by source: ${envNames.length}`);
console.log(failed ? 'PROPERTY_VISION_PREFLIGHT=BLOCKED' : 'PROPERTY_VISION_PREFLIGHT=PASS');
process.exitCode=failed?1:0;
