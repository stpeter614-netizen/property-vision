# Property Vision V50 — Cutover Verification

V50 is the **controlled production cutover layer** on top of V49.

### Added
- `supabase/v50_cutover_preflight.sql` — read-only database gate.
- `supabase/v50_cutover_verify.sql` — read-only post-activation checks and queue metrics.
- `supabase/v50_smoke_test.sql` — non-destructive smoke test.
- `V50_CUTOVER_RUNBOOK.md` — exact activation, testing, scheduler and rollback order.

### Safety
V50 does **not**:
- enable `pg_net`;
- create a Supabase cron job;
- add provider credentials;
- send a notification;
- modify the live database.

The current connected Supabase project remains WOX. Property Vision database activation must be run against the intended Property Vision database, not assumed to be the WOX project.
