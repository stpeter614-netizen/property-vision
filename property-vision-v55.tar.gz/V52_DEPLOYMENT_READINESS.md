# Property Vision V52 — Deployment Readiness

## Purpose
V52 restores the missing Next.js application bootstrap found during V51 inspection. No production database activation or Vercel deployment is performed by this package.

## Restored
- `package.json`
- `tsconfig.json`
- `next-env.d.ts`
- `next.config.ts`
- `app/layout.tsx`
- `app/globals.css`

## Existing application retained
The V50 application routes, APIs, Supabase migrations, notification worker, Vercel Cron configuration and documentation are retained unchanged except for the bootstrap files above.

## Required before production
1. Install dependencies.
2. Run `npm run build` successfully.
3. Configure required environment variables.
4. Connect this project to its intended Property Vision Supabase project (not WOX).
5. Run V50 cutover preflight and activation only against that intended database.
6. Deploy to a dedicated Property Vision Vercel project.
7. Browser-verify buyer and developer journeys.
