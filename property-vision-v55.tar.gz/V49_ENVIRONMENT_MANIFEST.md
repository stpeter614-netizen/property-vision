# Property Vision V49 — Environment Manifest

Set these in the **server-side Vercel production environment only**. Never expose provider secrets through `NEXT_PUBLIC_*` variables.

## Required for the notification worker
- `NEXT_PUBLIC_SUPABASE_URL` — Supabase project URL; safe to be public.
- `SUPABASE_SERVICE_ROLE_KEY` — server-only Supabase service-role key. **Never** prefix with `NEXT_PUBLIC_`.
- `NOTIFICATION_WORKER_SECRET` — private secret for internal worker calls.
- `CRON_SECRET` — Vercel Cron authorization secret.

## Email (optional until email delivery is activated)
- `RESEND_API_KEY`
- `RESEND_FROM_EMAIL`

## SMS (optional)
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_SMS_FROM`

## WhatsApp (optional)
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_WHATSAPP_FROM` — normally a WhatsApp-enabled sender such as `whatsapp:+...`.

## Activation rule
The database outbox can be installed before external providers are configured. Missing provider credentials produce controlled retryable failures rather than silently sending through an unknown provider.
