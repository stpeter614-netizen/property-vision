# Property Vision V50 — Production Cutover Runbook

## Goal
Move notification delivery from **packaged** to **verified production-ready** without silently enabling an external-message flood.

## Gate 0 — application
- Deploy the V49/V50 application to the intended Vercel project.
- Confirm `/api/notification-worker` exists in the deployed build.
- Confirm `vercel.json` contains the 5-minute cron entry.
- Configure production secrets before allowing the cron to run.

Required server-side variables:
- `NEXT_PUBLIC_SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `NOTIFICATION_WORKER_SECRET`
- `CRON_SECRET`
- `RESEND_API_KEY` + `RESEND_FROM_EMAIL` (email)
- `TWILIO_ACCOUNT_SID` + `TWILIO_AUTH_TOKEN` + `TWILIO_SMS_FROM` (SMS)
- `TWILIO_WHATSAPP_FROM` (WhatsApp, if enabled)

## Gate 1 — database
Run `supabase/v50_cutover_preflight.sql`.

**STOP** if any required check is false.

Then run `supabase/v49_production_activation.sql` once against the intended Property Vision database.

Then run `supabase/v50_cutover_verify.sql`.

## Gate 2 — first notification
Do not use a real customer notification as the first test.

Use an internal/test account and verify:
1. a Property Vision notification is created;
2. an `in_app` delivery exists and is `sent`;
3. an email delivery is queued only when a recipient email exists;
4. the worker claims the job;
5. successful provider delivery records `sent` and a provider message ID;
6. failed provider delivery records `failed` and a future retry time;
7. attempt count stops at five and the job becomes `cancelled`.

## Gate 3 — scheduler
Use **one scheduler only**.

Preferred: Vercel Cron → `/api/notification-worker`.

The worker accepts:
- Vercel Cron: `Authorization: Bearer <CRON_SECRET>`
- controlled internal invocation: `x-notification-worker-secret: <NOTIFICATION_WORKER_SECRET>`

Do not also create a Supabase Cron job unless deliberately switching schedulers.

## Gate 4 — provider activation
Activate providers one at a time:
1. email
2. SMS
3. WhatsApp

For each provider, send one controlled test to an owned test destination before exposing it to real buyers/developers.

## Rollback
If delivery misbehaves:
1. remove/disable the Vercel Cron entry first;
2. keep the database queue intact so jobs are not lost;
3. inspect `property_notification_deliveries`;
4. only use `v49_rollback.sql` if the database layer itself must be removed.

Do not delete queued delivery rows as a first response.
